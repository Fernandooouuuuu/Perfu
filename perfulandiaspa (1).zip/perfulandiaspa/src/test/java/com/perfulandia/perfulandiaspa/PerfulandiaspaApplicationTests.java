package com.perfulandia.perfulandiaspa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfulandiaspaApplicationTests {

	@Test
	void contextLoads() {
	}

}
