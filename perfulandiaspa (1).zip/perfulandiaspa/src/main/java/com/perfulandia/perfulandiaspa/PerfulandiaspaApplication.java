package com.perfulandia.perfulandiaspa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfulandiaspaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfulandiaspaApplication.class, args);
	}

}
